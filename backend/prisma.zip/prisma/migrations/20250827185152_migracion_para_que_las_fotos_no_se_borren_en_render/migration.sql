-- AlterTable
ALTER TABLE "public"."Usuario" ALTER COLUMN "updatedAt" DROP DEFAULT;
