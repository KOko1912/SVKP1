import NavBarUsuario from './NavBarUsuario';
export default function MisCompras() {
  return (
    <>
      <NavBarUsuario />
      <div style={{ padding: 16 }}>
        <h2>Mis compras</h2>
        <p>(En blanco) Aquí se listarán tus compras y estados.</p>
      </div>
    </>
  );
}