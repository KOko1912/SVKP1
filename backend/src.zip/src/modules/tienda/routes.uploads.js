// backend/src/modules/tienda/routes.uploads.js
const express = require('express');
const fs = require('fs');
const path = require('path');
const multer = require('multer');
const mime = require('mime-types');
const prisma = require('../../config/db');
const { StorageProvider } = require('@prisma/client');

const router = express.Router();

// === Helpers ======================================================
function getUserId(req) {
  const raw = req.headers['x-user-id'] || '';
  if (raw) return Number(raw);
  const auth = req.headers.authorization || '';
  const m = auth.match(/^Bearer\s+(\d+)$/i);
  return m ? Number(m[1]) : null;
}

const SLOT_FIELDS = { portada: 'portadaId', logo: 'logoId', banner: 'bannerId' };

// Directorio raíz público (sirviéndose en server.js con express.static)
const PUBLIC_DIR = path.resolve(process.cwd(), process.env.PUBLIC_DIR || 'public');

// Asegura una carpeta
function ensureDir(p) {
  if (!fs.existsSync(p)) fs.mkdirSync(p, { recursive: true });
}

// Middleware: cargar tienda del usuario
async function loadTienda(req, res, next) {
  try {
    const userId = getUserId(req);
    if (!userId) return res.status(401).json({ error: 'No autenticado' });
    const tienda = await prisma.tienda.findUnique({ where: { usuarioId: userId } });
    if (!tienda) return res.status(404).json({ error: 'Tienda no encontrada' });
    req.tienda = tienda;
    next();
  } catch (e) {
    console.error('[upload tienda] loadTienda error', e);
    res.status(500).json({ error: 'Error cargando tienda' });
  }
}

// Validar slot (sin regex en el path)
function validateSlot(req, res, next) {
  const slot = String(req.params.slot || '').toLowerCase();
  if (!Object.prototype.hasOwnProperty.call(SLOT_FIELDS, slot)) {
    return res.status(400).json({ error: 'slot inválido', allow: Object.keys(SLOT_FIELDS) });
  }
  req.slot = slot;
  next();
}

// Multer storage dinámico por tienda/slot
const storage = multer.diskStorage({
  destination(req, file, cb) {
    try {
      // req.tienda y req.slot ya existen por middlewares previos
      const dir = path.join(
        PUBLIC_DIR,
        'TiendaUploads',
        `tienda-${req.tienda.id}`,
        'branding',
        req.slot
      );
      ensureDir(dir);
      cb(null, dir);
    } catch (e) {
      cb(e);
    }
  },
  filename(req, file, cb) {
    const ext = mime.extension(file.mimetype) || 'bin';
    const safe = `${Date.now()}_${Math.random().toString(36).slice(2, 10)}.${ext}`;
    cb(null, safe);
  },
});

const upload = multer({
  storage,
  limits: {
    fileSize: 10 * 1024 * 1024, // 10 MB
  },
});

// === Rutas ========================================================
// POST /api/tienda/upload/:slot    (slot: portada | logo | banner)
// body: multipart/form-data -> field "file"
router.post('/upload/:slot', loadTienda, validateSlot, upload.single('file'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'Archivo ausente (field: file)' });

    // Ruta pública (lo que verá el frontend)
    // p.ej. /TiendaUploads/tienda-1/branding/portada/123_abc.webp
    const relKey = path
      .join('TiendaUploads', `tienda-${req.tienda.id}`, 'branding', req.slot, req.file.filename)
      .replace(/\\/g, '/'); // win compat
    const publicUrl = `/${relKey}`;

    // Crear Media
    const media = await prisma.media.create({
      data: {
        provider: StorageProvider.LOCAL,
        key: relKey,     // único con provider
        url: publicUrl,  // como lo servimos estáticamente
        mime: req.file.mimetype || mime.lookup(req.file.originalname) || null,
        sizeBytes: req.file.size || null,
        width: null,
        height: null,
        checksum: null,
      },
    });

    // Ligar a tienda (portadaId / logoId / bannerId)
    const field = SLOT_FIELDS[req.slot];
    await prisma.tienda.update({
      where: { id: req.tienda.id },
      data: { [field]: media.id },
    });

    res.json({
      ok: true,
      mediaId: media.id,
      url: media.url, // el front ya puede usarlo directo (servido por express.static)
      slot: req.slot,
    });
  } catch (e) {
    console.error('[upload tienda] error', e);
    res.status(500).json({ error: 'No se pudo subir la imagen', message: e?.message || null });
  }
});

module.exports = router;
