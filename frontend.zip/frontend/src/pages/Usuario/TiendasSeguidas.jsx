import { useEffect, useRef, useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import NavBarUsuario from './NavBarUsuario';
import {
  FiSearch, FiExternalLink, FiGlobe, FiMapPin, FiUsers, FiHeart
} from 'react-icons/fi';
import './usuario.css';

const RAW_API = import.meta.env.VITE_API_URL || 'http://localhost:5000';
const API = RAW_API.replace(/\/$/, '');
const FOLLOW_KEY = 'stores_following';

/* ================= Helpers de red y media ================= */
const tryJson = async (url, init) => {
  try {
    const r = await fetch(url, init);
    const t = await r.text();
    let d = null; try { d = JSON.parse(t); } catch {}
    if (!r.ok || d?.error) return null;
    return d;
  } catch { return null; }
};

// URL pública (acepta absolutas - Supabase/Cloud -, o rutas del backend)
const toPublicUrl = (u) => {
  if (!u) return '';
  if (typeof u !== 'string') return '';
  const s = u.trim();
  if (!s) return '';
  if (/^https?:\/\//i.test(s)) return s;
  if (s.startsWith('/')) return `${API}${s}`;
  return `${API}/${s}`;
};

const withCacheBuster = (url, stamp = Date.now()) =>
  url ? `${url}${url.includes('?') ? '&' : '?'}t=${stamp}` : '';

/* ----------------- normalizadores de logo/portada ----------------- */
const pickStoreLogo = (t) => {
  if (t?.logo?.url) return t.logo.url;
  if (t?.branding?.logo?.url) return t.branding.logo.url;
  if (typeof t?.logo === 'string') return t.logo;
  if (t?.logoUrl) return t.logoUrl;
  return '';
};

const pickStoreCover = (t) => {
  if (t?.portada?.url) return t.portada.url;
  if (t?.banner?.url) return t.banner.url;
  if (t?.branding?.portada?.url) return t.branding.portada.url;
  if (t?.branding?.banner?.url) return t.branding.banner.url;
  if (t?.portadaUrl) return t.portadaUrl;
  if (t?.banner) return t.banner;
  return '';
};

const storeKey = (t) => t?.slug || t?.publicUuid || String(t?.id || '');
const internalPathForStore = (t) => {
  if (t?.slug) return `/t/${encodeURIComponent(t.slug)}`;
  if (t?.publicUuid) return `/s/${encodeURIComponent(t.publicUuid)}`;
  return '';
};
const externalUrlForStore  = (t) =>
  t?.urlPublica || t?.urlPrincipal || t?.web || t?.url || '';

/* ========= intenta resolver una tienda por clave (slug/uuid/id) ========= */
async function fetchPublicStoreByKey(key) {
  if (!key) return null;
  const k = String(key).trim();

  // 1) slug
  let d = await tryJson(`${API}/api/tienda/public/${encodeURIComponent(k)}`);
  if (d && (d.slug || d.id)) return d;

  // 2) uuid pública
  d = await tryJson(`${API}/api/tienda/public/uuid/${encodeURIComponent(k)}`);
  if (d && (d.slug || d.id)) return d;

  // 3) by-id (numérico)
  if (/^\d+$/.test(k)) {
    d = await tryJson(`${API}/api/tienda/public/by-id/${k}`);
    if (d && (d.slug || d.id)) return d;
  }
  return null;
}

/* ============================= Página ============================= */
export default function TiendasSeguidas() {
  const navigate = useNavigate();

  // UI
  const [q, setQ] = useState('');
  const [sort, setSort] = useState('relevance'); // relevance | name | followers | city
  const [onlyFollowing, setOnlyFollowing] = useState(false);

  // Data
  const [stores, setStores] = useState([]);
  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState('');
  const [page, setPage] = useState(1);

  // Follow state (persistente)
  const [usuario, setUsuario] = useState(null);
  const [following, setFollowing] = useState(new Set());
  const persistTimer = useRef(null);

  const usesHashRouter = typeof window !== 'undefined' && window.location.hash.startsWith('#/');

  /* ============== Usuario y suscripciones ============== */
  useEffect(() => {
    try {
      const u = JSON.parse(localStorage.getItem('usuario') || 'null');
      if (u) {
        setUsuario(u);
        hydrateFollowingFromUser(u);
      }
    } catch {}

    (async () => {
      try {
        const uLS = JSON.parse(localStorage.getItem('usuario') || 'null');
        if (!uLS?.id) return;
        const r = await fetch(`${API}/api/usuarios/${uLS.id}`);
        if (!r.ok) return;
        const data = await r.json();
        if (!data?.usuario) return;
        localStorage.setItem('usuario', JSON.stringify(data.usuario));
        setUsuario(data.usuario);
        hydrateFollowingFromUser(data.usuario);
      } catch {}
    })();
  }, []);

  function hydrateFollowingFromUser(u) {
    try {
      let src = u?.suscripciones;
      if (typeof src === 'string') { try { src = JSON.parse(src); } catch {} }
      let arr = [];
      if (Array.isArray(src)) arr = src;
      else if (src && typeof src === 'object') arr = src.tiendas || src.following || src.stores || [];
      if (!arr?.length) arr = JSON.parse(localStorage.getItem(FOLLOW_KEY) || '[]');
      const keys = (arr || []).map(String).filter(Boolean);
      setFollowing(new Set(keys));
      localStorage.setItem(FOLLOW_KEY, JSON.stringify(keys));
    } catch {
      const localArr = JSON.parse(localStorage.getItem(FOLLOW_KEY) || '[]');
      setFollowing(new Set(localArr));
    }
  }

  function persistFollowingDebounced(nextSet) {
    const arr = [...nextSet];
    localStorage.setItem(FOLLOW_KEY, JSON.stringify(arr));
    if (!usuario?.id) return;
    if (persistTimer.current) clearTimeout(persistTimer.current);
    persistTimer.current = setTimeout(async () => {
      try {
        let r = await fetch(`${API}/api/usuarios/${usuario.id}/suscripciones`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ suscripciones: arr })
        });
        if (!r.ok) {
          r = await fetch(`${API}/api/usuarios/${usuario.id}`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ suscripciones: arr })
          });
        }
        try {
          const data = await r.json();
          if (data?.usuario) {
            localStorage.setItem('usuario', JSON.stringify(data.usuario));
            setUsuario(data.usuario);
          }
        } catch {}
      } catch {}
    }, 300);
  }

  const isFollowing = (t) => {
    const k = storeKey(t);
    return k && following.has(String(k));
  };

  const toggleFollow = (t) => {
    const k = storeKey(t);
    if (!k) return;
    setFollowing((prev) => {
      const next = new Set(prev);
      next.has(k) ? next.delete(k) : next.add(k);
      persistFollowingDebounced(next);
      return next;
    });
  };

  /* ====================== Fetch principal ====================== */
  const fetchStores = async (signal) => {
    setLoading(true);
    setMsg('');

    const results = [];

    // 1) Si hay texto, intenta resolverlo como slug/uuid/id (endpoints públicos que existen)
    const term = q.trim();
    if (term) {
      const resolved = await fetchPublicStoreByKey(term);
      if (resolved) {
        results.push(resolved);
        setStores(results);
        setLoading(false);
        return;
      }

      // Como “bonus”, si tuvieras /api/tiendas/search con q (a veces existe),
      // lo intentamos SOLO cuando hay término:
      const extra = await tryJson(`${API}/api/tiendas/search?q=${encodeURIComponent(term)}&page=${page}&limit=24`);
      const list = extra?.items || extra?.data || extra?.tiendas || (Array.isArray(extra) ? extra : []);
      if (Array.isArray(list) && list.length) {
        setStores(list);
        setLoading(false);
        return;
      }

      setStores([]);
      setMsg('No se encontraron tiendas para esa clave.');
      setLoading(false);
      return;
    }

    // 2) Sin término: carga seguidas del usuario (local/servidor) resolviendo cada clave
    const followArr = JSON.parse(localStorage.getItem(FOLLOW_KEY) || '[]');
    if (Array.isArray(followArr) && followArr.length) {
      const batch = await Promise.allSettled(followArr.map(k => fetchPublicStoreByKey(k)));
      for (const it of batch) {
        if (it.status === 'fulfilled' && it.value) results.push(it.value);
      }
    }

    // 3) Si estás logueado como vendedor, intenta incluir tu tienda “me”
    try {
      const uLS = JSON.parse(localStorage.getItem('usuario') || 'null');
      const headers = uLS?.id ? { 'x-user-id': uLS.id } : undefined;
      const me = await tryJson(`${API}/api/tienda/me`, { headers, signal });
      if (me && (me.isPublished || me.slug)) {
        results.push(me);
      }
    } catch {}

    // De-duplicar (por slug o id)
    const seen = new Set();
    const uniq = [];
    for (const t of results) {
      const key = t?.slug || `id:${t?.id}`;
      if (key && !seen.has(key)) { seen.add(key); uniq.push(t); }
    }

    setStores(uniq);
    setMsg(uniq.length ? '' : 'Aún no sigues tiendas. Busca por slug y pulsa “Seguir”.');
    setLoading(false);
  };

  useEffect(() => {
    const ctrl = new AbortController();
    const t = setTimeout(() => fetchStores(ctrl.signal), 250);
    return () => { ctrl.abort(); clearTimeout(t); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [q, page]);

  /* ====================== Derivados y UI ====================== */
  const filtered = useMemo(() => {
    const base = onlyFollowing ? stores.filter((t) => isFollowing(t)) : stores;
    return base;
  }, [stores, onlyFollowing, following]);

  const visibleStores = useMemo(() => {
    let list = filtered;
    if (q.trim()) {
      const term = q.trim().toLowerCase();
      list = list.filter((t) => {
        const hay = `${t?.nombre || ''} ${t?.descripcion || ''} ${t?.ciudad || ''} ${t?.categoria || ''}`.toLowerCase();
        return hay.includes(term) || (t?.slug || '').toLowerCase().includes(term);
      });
    }
    switch (sort) {
      case 'name':
        list = [...list].sort((a, b) => (a?.nombre || '').localeCompare(b?.nombre || ''));
        break;
      case 'followers':
        list = [...list].sort((a, b) => (b?.seguidores || 0) - (a?.seguidores || 0));
        break;
      case 'city':
        list = [...list].sort((a, b) => (a?.ciudad || '').localeCompare(b?.ciudad || ''));
        break;
      default: // relevance
        break;
    }
    return list;
  }, [filtered, q, sort]);

  const visitStore = (t) => {
    const internal = internalPathForStore(t);
    const external = externalUrlForStore(t);
    if (internal) {
      if (usesHashRouter) window.location.hash = internal;
      else navigate(internal);
    } else if (external) {
      window.open(external, '_blank', 'noopener,noreferrer');
    } else if (t?.slug) {
      const p = usesHashRouter ? `#/t/${t.slug}` : `/t/${t.slug}`;
      usesHashRouter ? (window.location.hash = p) : navigate(p);
    } else {
      alert('Esta tienda aún no tiene URL pública.');
    }
  };

  return (
    <>
      <NavBarUsuario />

      <div className="page page--dark-svk">
        <main className="container-svk">
          {/* Header + controles */}
          <header className="card-svk" style={{ marginBottom: 16 }}>
            <div className="block-title" style={{ marginBottom: 10 }}>
              <span className="icon"><FiSearch /></span>
              <h2>Explorar / Tiendas seguidas</h2>
            </div>
            <p className="subtitle-svk" style={{ marginBottom: 14 }}>
              Escribe el <strong>slug</strong> de una tienda para buscarla, o mira tus tiendas seguidas.
            </p>

            <div className="shop-controls">
              <div className="shop-searchbar dark">
                <FiSearch />
                <input
                  value={q}
                  onChange={(e) => { setPage(1); setQ(e.target.value); }}
                  placeholder="Buscar por SLUG, UUID o ID… (ej. tiendasonline)"
                  aria-label="Buscar tiendas"
                />
              </div>

              <div className="shop-right-controls">
                <label className="toggle small" title="Mostrar solo tiendas que sigues">
                  <input
                    type="checkbox"
                    checked={onlyFollowing}
                    onChange={(e) => setOnlyFollowing(e.target.checked)}
                  />
                  <span>Solo seguidas</span>
                </label>

                <select
                  className="select-svk"
                  value={sort}
                  onChange={(e) => setSort(e.target.value)}
                  aria-label="Ordenar resultados"
                >
                  <option value="relevance">Relevancia</option>
                  <option value="name">Nombre (A–Z)</option>
                  <option value="followers">Más seguidas</option>
                  <option value="city">Ciudad (A–Z)</option>
                </select>
              </div>
            </div>
          </header>

          {/* Resultados */}
          {loading ? (
            <section className="shop-grid">
              {Array.from({ length: 8 }).map((_, i) => (
                <article key={i} className="shop-card skeleton" />
              ))}
            </section>
          ) : (
            <>
              {!visibleStores.length ? (
                <div className="card-svk empty-state">
                  <p className="subtitle-svk">
                    {msg || (onlyFollowing
                      ? 'No hay coincidencias entre tus tiendas seguidas.'
                      : 'Sin resultados. Prueba buscando por el slug (ej. tiendasonline).')}
                  </p>
                </div>
              ) : (
                <section className="shop-grid">
                  {visibleStores.map((t, i) => {
                    const logoRaw = pickStoreLogo(t);
                    const coverRaw = pickStoreCover(t);
                    const stamp = t?.updatedAt || Date.now();

                    const logo = withCacheBuster(toPublicUrl(logoRaw), stamp);
                    const hdr  = withCacheBuster(toPublicUrl(coverRaw), stamp);
                    const external = externalUrlForStore(t);
                    const followed = isFollowing(t);

                    return (
                      <article key={`${storeKey(t) || i}`} className="shop-card card-svk shop-card--fx">
                        {/* Portada 16:9 */}
                        <div className="shop-cover" style={hdr ? { backgroundImage: `url(${hdr})` } : undefined} />

                        <div className="shop-body">
                          {/* Cabecera */}
                          <div className="shop-head">
                            <div className="shop-avatar">
                              {logo ? <img src={logo} alt="" /> : <span className="shop-avatar-fallback">SVK</span>}
                            </div>
                            <div className="shop-head-text">
                              <h3 className="shop-name">{t?.nombre || 'Tienda sin nombre'}</h3>
                              <p className="shop-desc">{t?.descripcion || '—'}</p>
                            </div>
                          </div>

                          {/* Meta */}
                          <div className="shop-meta">
                            {t?.ciudad && (<span><FiMapPin /> {t.ciudad}</span>)}
                            {(t?.seguidores != null) && (<span><FiUsers /> {t.seguidores} seguidores</span>)}
                            {t?.categoria && <span className="shop-tag">#{t.categoria}</span>}
                            {followed && <span className="shop-badge">Siguiendo</span>}
                          </div>

                          {/* Acciones */}
                          <div className="shop-actions">
                            <button
                              className="btn btn-outline"
                              onClick={() => visitStore(t)}
                              title="Abrir sitio público de la tienda"
                            >
                              {external ? <FiExternalLink /> : <FiGlobe />} Visitar tienda
                            </button>

                            <button
                              className={`btn btn-ghost ${followed ? 'active' : ''}`}
                              onClick={() => toggleFollow(t)}
                              title={followed ? 'Dejar de seguir' : 'Seguir tienda'}
                              aria-pressed={followed}
                            >
                              <FiHeart /> {followed ? 'Siguiendo' : 'Seguir'}
                            </button>
                          </div>
                        </div>
                      </article>
                    );
                  })}
                </section>
              )}

              {/* Paginación simple (útil cuando exista listado real) */}
              <div className="pager">
                <button
                  className="btn btn-ghost"
                  disabled={page <= 1}
                  onClick={() => setPage((p) => Math.max(1, p - 1))}
                >
                  Anterior
                </button>
                <span style={{ color: 'var(--svk-muted)' }}>Página {page}</span>
                <button className="btn btn-ghost" onClick={() => setPage((p) => p + 1)}>
                  Siguiente
                </button>
              </div>
            </>
          )}
        </main>
      </div>
    </>
  );
}
