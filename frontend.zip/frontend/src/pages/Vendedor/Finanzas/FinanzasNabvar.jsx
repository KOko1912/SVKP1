import React, { useEffect, useState } from "react";
import { FiInbox, FiTrendingUp, FiUser, FiChevronLeft } from "react-icons/fi";
import "./Finanzaz.css";

/**
 * Navbar de Finanzas
 * - Sticky, con blur y sombra.
 * - Contenido centrado al ancho del contenedor (como el resto de la página).
 * - Botón Volver a Perfil (izquierda) + título (centro).
 * - Tabs (Entrada / Ingresos) en una segunda fila, centradas.
 * - Sin botón de "Actualizar".
 */
export default function FinanzasNabvar() {
  const [active, setActive] = useState("inicio");

  useEffect(() => {
    const setFromHash = () => {
      const h = window.location.hash || "";
      if (/#\/vendedor\/finanzas(\/)?$/.test(h)) return setActive("inicio");
      if (/#\/vendedor\/finanzas\/ingresos(\/)?$/.test(h))
        return setActive("ingresos");
      setActive("inicio");
    };
    setFromHash();
    window.addEventListener("hashchange", setFromHash);
    return () => window.removeEventListener("hashchange", setFromHash);
  }, []);

  const perfilHref = "#/vendedor/perfil";

  return (
    <nav
      className="finz-navbar"
      aria-label="Navegación de finanzas"
      style={{
        position: "sticky",
        top: 0,
        zIndex: 40,
        backdropFilter: "saturate(120%) blur(8px)",
        background: "rgba(16,16,20,.75)",
        borderBottom: "1px solid rgba(255,255,255,.06)",
        boxShadow: "0 6px 20px rgba(0,0,0,.14)",
        padding: "8px 0",
      }}
    >
      <div className="finz-navbar-inner">
        {/* Fila 1: Back a Perfil + Título */}
        <div
          className="finz-row"
          style={{
            display: "grid",
            gridTemplateColumns: "auto 1fr",
            alignItems: "center",
            gap: 12,
          }}
        >
          <a
            href={perfilHref}
            className="finz-tab"
            title="Volver al perfil del vendedor"
            style={{
              display: "inline-flex",
              alignItems: "center",
              gap: 8,
              padding: "9px 12px",
              borderRadius: 12,
              border: "1px solid rgba(255,255,255,.08)",
              background: "rgba(255,255,255,.03)",
              whiteSpace: "nowrap",
            }}
          >
            <FiChevronLeft />
            <FiUser />
            <span style={{ fontWeight: 700 }}>Perfil</span>
          </a>

          <div
            className="finz-title"
            style={{
              textAlign: "center",
              fontWeight: 800,
              letterSpacing: 0.2,
              userSelect: "none",
              color: "#fff",
              fontSize: "clamp(0.95rem, 2.2vw, 1.05rem)",
            }}
          >
            Panel de Finanzas
          </div>
        </div>

        {/* Fila 2: Tabs */}
        <div
          className="finz-tabs"
          role="tablist"
          style={{
            marginTop: 10,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            gap: 8,
            flexWrap: "wrap",
          }}
        >
          <a
            href="#/vendedor/finanzas"
            role="tab"
            aria-selected={active === "inicio" ? "true" : "false"}
            className={`finz-tab ${active === "inicio" ? "is-active" : ""}`}
            style={tabStyle(active === "inicio")}
          >
            <FiInbox />
            <span>Entrada</span>
          </a>

          <a
            href="#/vendedor/finanzas/ingresos"
            role="tab"
            aria-selected={active === "ingresos" ? "true" : "false"}
            className={`finz-tab ${active === "ingresos" ? "is-active" : ""}`}
            style={tabStyle(active === "ingresos")}
          >
            <FiTrendingUp />
            <span>Ingresos</span>
          </a>
        </div>
      </div>
    </nav>
  );
}

/** Estilo de pestañas (activo/inactivo) */
function tabStyle(active) {
  return {
    display: "inline-flex",
    alignItems: "center",
    gap: 8,
    padding: "9px 14px",
    borderRadius: 12,
    border: active
      ? "1px solid var(--primary, #6d28d9)"
      : "1px solid rgba(255,255,255,.08)",
    background: active
      ? "linear-gradient(135deg, var(--primary,#6d28d9), var(--secondary,#c026d3))"
      : "rgba(255,255,255,.03)",
    color: active ? "#fff" : "var(--gray-200)",
    fontWeight: 700,
    whiteSpace: "nowrap",
    transition: "all .2s ease",
  };
}
