-- AlterTable
ALTER TABLE "public"."Tienda" ADD COLUMN     "homeLayout" JSONB;
